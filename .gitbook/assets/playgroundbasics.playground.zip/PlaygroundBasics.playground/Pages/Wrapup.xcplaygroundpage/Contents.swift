//: ## Wrapup
//: **ขอแสดงความยินดี** สำหรับก้าวแรกสู่การเป็นนักพัฒนาที่ยิ่งใหญ่ !
/*:
สิ่งที่คุณได้เรียนรู้ในบทเรียนที่ผ่านมา คือ
 - การใช้ playground เพื่อการเขียนคำสั่ง
 - การสร้าง Comment ลงใน Souce code
 - การแก้ไขความบกพร่อง (_error_) ที่อาจเกิดขึ้นได้ในชุดคำสั่งของคุณ
*/
//: ยังมีอีกหลายสิ่งที่คุณจะต้องเรียนรู้เกี่ยวกับการเขียนคำสั่งด้วยภาษา Swift เพื่อการพัฒนา iOS Application \
//: คุณสามารถเข้าร่วมกลุ่มเพื่อศึกษาภาษา Swift ได้ที่ [FB:Everyone Can Code with Swift](https://www.facebook.com/groups/everyonecancode/)
//:
/*:
เอกสารนี้ถูกเรียบเรียงขึ้นใหม่โดย อาจารย์ธิติ ธีระเธียร \
ต้นฉบับจาก Intro to Application Development โดย Apple Inc.
*/
/*:
 _This work is licensed under a Creative Commons Attribution-NonCommercial 4.0 International License._

 _Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files (the "Software"), to deal in the Software without restriction, including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so, subject to the following conditions:_
 */
/*:
_You are free to:_
- _**Share** — copy and redistribute the material in any medium or format._
- _**Adapt** — remix, transform, and build upon the material._
- _**Attribution** — You must give appropriate credit, provide a link to the license, and indicate if changes were made. You may do so in any reasonable manner, but not in any way that suggests the licensor endorses you or your use._
- _**NonCommercial** — You may not use the material for commercial purposes._
*/
//:
//:
//:[Previous](@previous)  |  หน้า 7 จาก 7
